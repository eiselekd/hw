
main()
{
	printf("\n\n  Hello LEON3 World!!!\n");
	printf("\n  Simulation will now be halted through error mode...\n\n");
}
