
main()

{
	report_start();

	base_test();

        report_end();
}
