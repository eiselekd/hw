/* #define MCFG1 0x10380033 */
/* #define MCFG2 0xe6B80e50 */
/* #define MCFG3 0x000ff000 */
/* #define ASDCFG 0xfff00100 */
/* #define DSDCFG 0x922083cd */
/* #define L2MCTRLIO 0x80000000 */
#define IRQCTRL   0x80000200
#define RAMSTART  0x40000000
#define RAMSIZE   0x00100000

