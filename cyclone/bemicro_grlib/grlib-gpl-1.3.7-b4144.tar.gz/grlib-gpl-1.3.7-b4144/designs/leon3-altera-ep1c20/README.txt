
This leon3 design is tailored to the Altera Nios Cyclone Development board.

http://www.altera.com/products/devkits/altera/kit-nios_1C20.html

