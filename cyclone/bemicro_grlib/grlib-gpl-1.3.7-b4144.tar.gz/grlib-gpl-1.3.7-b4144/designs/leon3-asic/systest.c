
main()

{
   report_start();
   base_test();
   greth_test(0x80000d00);
   report_end();
}
