
struct ahbstat {
    volatile int memstatus;
    volatile int failaddr;
};



