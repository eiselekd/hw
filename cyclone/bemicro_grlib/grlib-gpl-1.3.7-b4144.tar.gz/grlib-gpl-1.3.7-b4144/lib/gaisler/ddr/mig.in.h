
#ifndef CONFIG_MIG_DDR3
#define CONFIG_MIG_DDR3 0
#endif

#ifndef CONFIG_MIG_DDR2
#define CONFIG_MIG_DDR2 0
#endif

#ifndef CONFIG_MIG_RANKS
#define CONFIG_MIG_RANKS 1
#endif

#ifndef CONFIG_MIG_COLBITS
#define CONFIG_MIG_COLBITS 10
#endif

#ifndef CONFIG_MIG_ROWBITS
#define CONFIG_MIG_ROWBITS 13
#endif

#ifndef CONFIG_MIG_BANKBITS
#define CONFIG_MIG_BANKBITS 2
#endif

#ifndef CONFIG_MIG_HMASK
#define CONFIG_MIG_HMASK F00
#endif
