This directory contains fpga pinout and xilinx coregen ip setup files used by the reference designs.

For more information please visit www.xilinx.com/vc707