/*
 * ENC_memtester.h
 *
 *  Created on: 06.05.2015
 *      Author: shuerlim
 */

#ifndef XIL_MEMTESTER_H_
#define XIL_MEMTESTER_H_

#include "types.h"

ul run_ddr_test(ul BaseAddr, ul Length, ul loops, ul full_test, ul Verbose);

#endif /* XIL_MEMTESTER_H_ */
