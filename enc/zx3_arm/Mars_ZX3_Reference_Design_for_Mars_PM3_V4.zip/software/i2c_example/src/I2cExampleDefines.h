#if TARGET_MODULE == MARS_ZX2
	#define CONFIG_MODULE_NAME                                     MARS_ZX2_MODULE_NAME
#elif TARGET_MODULE == MARS_ZX3
	#define CONFIG_MODULE_NAME                                     MARS_ZX3_MODULE_NAME
#elif TARGET_MODULE == MERCURY_ZX1
	#define CONFIG_MODULE_NAME                                     MERCURY_ZX1_MODULE_NAME
#elif TARGET_MODULE == MERCURY_ZX5
	#define CONFIG_MODULE_NAME                                     MERCURY_ZX5_MODULE_NAME
#elif TARGET_MODULE == MERCURY_XU1
	#define CONFIG_MODULE_NAME                                     MERCURY_XU1_MODULE_NAME
#elif TARGET_MODULE == MERCURY_KX1
	#define CONFIG_MODULE_NAME                                     MERCURY_KX1_MODULE_NAME
#elif TARGET_MODULE == MERCURY_KX2
	#define CONFIG_MODULE_NAME                                     MERCURY_KX2_MODULE_NAME
#elif TARGET_MODULE == MARS_AX3
	#define CONFIG_MODULE_NAME                                     MARS_AX3_MODULE_NAME
#elif TARGET_MODULE == MERCURY_SA1
	#define CONFIG_MODULE_NAME                                     MERCURY_SA1_MODULE_NAME
#elif TARGET_MODULE == MERCURY_SA2
	#define CONFIG_MODULE_NAME                                     MERCURY_SA2_MODULE_NAME
#elif TARGET_MODULE == MERCURY_AA1
	#define CONFIG_MODULE_NAME                                     MERCURY_AA1_MODULE_NAME
#elif TARGET_MODULE == MARS_XU3
	#define CONFIG_MODULE_NAME                                     MARS_XU3_MODULE_NAME
#elif TARGET_MODULE == COSMOS_XZQ10
	#define CONFIG_MODULE_NAME                                     COSMOS_XZQ10_MODULE_NAME
#elif TARGET_MODULE == MARS_MA3
	#define CONFIG_MODULE_NAME                                     MARS_MA3_MODULE_NAME
#endif




